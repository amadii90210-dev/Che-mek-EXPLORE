import { i as __toESM } from "../_runtime.mjs";
import { G as require_jsx_runtime, K as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as MathUtils, E as MeshBasicMaterial, G as TorusGeometry, O as MeshStandardMaterial, T as Mesh, W as SphereGeometry, _ as Group, n as BoxGeometry, o as CapsuleGeometry, s as CircleGeometry } from "../_libs/three.mjs";
import { a as MapPin, c as BookOpen, i as RotateCcw, n as Volume2, o as Footprints, s as Compass, t as VolumeX } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-B_JRJFpk.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var AVATAR_META = [
	{
		id: "maja",
		name: "Maja",
		line: "Płaszcz miodowy",
		blurb: "Szalik pod szyją, lekki krok po płycie placu."
	},
	{
		id: "olek",
		name: "Olek",
		line: "Granatowa kurtka",
		blurb: "Spokojny chód wzdłuż Krakowskiej."
	},
	{
		id: "rysiek",
		name: "Rysiek",
		line: "Bluza z osiedla Baty",
		blurb: "Czapka, robocza bluza, pamięć fabryki obuwia."
	}
];
var PALETTES = {
	maja: {
		skin: 15251608,
		hair: 2760988,
		top: 13206586,
		bottom: 2896192,
		shoe: 2367004,
		accent: 8007224,
		hairStyle: "bun",
		scale: .96,
		shoulder: .2
	},
	olek: {
		skin: 14131836,
		hair: 3811874,
		top: 2372170,
		bottom: 13352870,
		shoe: 3812904,
		accent: 15985887,
		hairStyle: "short",
		scale: 1,
		shoulder: .23
	},
	rysiek: {
		skin: 12880482,
		hair: 4076588,
		top: 12872236,
		bottom: 4870496,
		shoe: 2761758,
		accent: 14275524,
		hairStyle: "cap",
		scale: 1.06,
		shoulder: .28
	}
};
function mat(hex, rough = .74) {
	return new MeshStandardMaterial({
		color: hex,
		roughness: rough,
		metalness: .02
	});
}
function limb(len, rad, cloth, tip) {
	const pivot = new Group();
	const upper = new Mesh(new CapsuleGeometry(rad, len * .55, 2, 6), cloth);
	upper.position.y = -len * .38;
	const end = new Mesh(new SphereGeometry(rad * 1.15, 8, 6), tip);
	end.position.y = -len * .78;
	end.scale.set(1, .72, 1.25);
	pivot.add(upper, end);
	return pivot;
}
function createAvatar(id) {
	const p = PALETTES[id];
	const root = new Group();
	root.scale.setScalar(p.scale);
	const skin = mat(p.skin, .62);
	const hair = mat(p.hair, .55);
	const top = mat(p.top, .8);
	const bottom = mat(p.bottom, .82);
	const shoe = mat(p.shoe, .5);
	const accent = mat(p.accent, .6);
	const legL = limb(.46, .075, bottom, shoe);
	const legR = limb(.46, .075, bottom, shoe);
	legL.position.set(-.11, .86, 0);
	legR.position.set(.11, .86, 0);
	const torso = new Group();
	torso.position.y = .86;
	const coat = new Mesh(new CapsuleGeometry(p.shoulder, .42, 3, 8), top);
	coat.position.y = .28;
	torso.add(coat);
	const collar = new Mesh(new BoxGeometry(.16, .055, .08), accent);
	collar.position.set(0, .5, p.shoulder * .45);
	torso.add(collar);
	const armL = limb(.38, .055, top, skin);
	const armR = limb(.38, .055, top, skin);
	armL.position.set(-p.shoulder - .02, .46, 0);
	armR.position.set(p.shoulder + .02, .46, 0);
	torso.add(armL, armR);
	const headPivot = new Group();
	headPivot.position.y = .58;
	const head = new Mesh(new SphereGeometry(.145, 12, 10), skin);
	head.scale.set(1, 1.05, 1);
	headPivot.add(head);
	const nose = new Mesh(new SphereGeometry(.028, 6, 6), skin);
	nose.position.set(0, -.01, .138);
	headPivot.add(nose);
	if (p.hairStyle === "bun") {
		const cap = new Mesh(new SphereGeometry(.15, 10, 8), hair);
		cap.scale.set(1.02, .68, 1.05);
		cap.position.y = .055;
		const bun = new Mesh(new SphereGeometry(.068, 8, 8), hair);
		bun.position.set(0, .1, -.08);
		const scarf = new Mesh(new TorusGeometry(.09, .022, 6, 10), accent);
		scarf.position.set(0, -.11, .02);
		scarf.rotation.x = Math.PI / 2;
		headPivot.add(cap, bun, scarf);
	} else if (p.hairStyle === "short") {
		const cap = new Mesh(new SphereGeometry(.152, 10, 8), hair);
		cap.scale.set(1.02, .6, 1.04);
		cap.position.y = .07;
		headPivot.add(cap);
	} else {
		const cap = new Mesh(new SphereGeometry(.155, 10, 8, 0, Math.PI * 2, 0, Math.PI / 2), hair);
		cap.position.y = .02;
		const brim = new Mesh(new BoxGeometry(.22, .018, .11), hair);
		brim.position.set(0, .02, .12);
		headPivot.add(cap, brim);
	}
	torso.add(headPivot);
	root.add(legL, legR, torso);
	root.traverse((obj) => {
		const mesh = obj;
		if (mesh.isMesh) {
			mesh.castShadow = true;
			mesh.receiveShadow = true;
			mesh.userData.avatarId = id;
		}
	});
	root.userData.avatarId = id;
	root.userData.parts = {
		legL,
		legR,
		armL,
		armR,
		torso
	};
	const discMat = new MeshBasicMaterial({
		color: 14866116,
		transparent: true,
		opacity: .9,
		depthWrite: false
	});
	const disc = new Mesh(new CircleGeometry(.52, 22), discMat);
	disc.rotation.x = -Math.PI / 2;
	disc.position.y = .06;
	disc.userData.avatarId = id;
	root.add(disc);
	root.userData.disc = disc;
	return root;
}
function poseAvatar(root, speed, phase, reduce) {
	const parts = root.userData.parts;
	const walk = MathUtils.clamp(Math.abs(speed) / 3.4, 0, 1);
	if (reduce || walk < .05) {
		parts.legL.rotation.x = 0;
		parts.legR.rotation.x = 0;
		parts.armL.rotation.x = 0;
		parts.armR.rotation.x = 0;
		parts.torso.rotation.x = 0;
		parts.torso.position.y = .86 + Math.sin(phase) * .01;
		return;
	}
	const swing = Math.sin(phase) * walk;
	parts.legL.rotation.x = swing * .9;
	parts.legR.rotation.x = -swing * .9;
	parts.armL.rotation.x = -swing * .7;
	parts.armR.rotation.x = swing * .7;
	parts.torso.position.y = .86 + Math.abs(Math.sin(phase * 2)) * .03 * walk;
	parts.torso.rotation.x = .1 * walk;
}
var SAVE_KEY = "chelmek-walk-v1";
var ACCENT = {
	maja: "bg-gold",
	olek: "bg-pine",
	rysiek: "bg-brick"
};
function kindLabel(kind, name) {
	const n = name.toLowerCase();
	if (n.includes("przemsza") || kind === "river") return "Rzeka";
	if (n.includes("kościół") || n.includes("kaplica") || kind === "church") return "Kościół";
	if (n.includes("urząd")) return "Urząd";
	if (n.includes("dworzec") || kind === "station") return "Kolej";
	if (kind === "cinema" || n.includes("kino")) return "Kino";
	if (kind === "memorial" || kind === "monument" || n.includes("pomnik") || n.includes("aussen") || n.includes("faszyzm")) return "Pamięć";
	if (n.includes("biblioteka")) return "Biblioteka";
	if (n.includes("poczta")) return "Poczta";
	if (n.includes("ośrodek")) return "Kultura";
	if (n.includes("osp")) return "Straż";
	if (n.includes("krasnal") || n.includes("młyń")) return "Ciekawostka";
	return "Miejsce";
}
function compassLabel(yaw) {
	const deg = (-yaw * 180 / Math.PI % 360 + 360) % 360;
	return [
		"N",
		"NE",
		"E",
		"SE",
		"S",
		"SW",
		"W",
		"NW"
	][Math.round(deg / 45) % 8] ?? "N";
}
function ChelmekGame() {
	const viewRef = (0, import_react.useRef)(null);
	const miniRef = (0, import_react.useRef)(null);
	const handleRef = (0, import_react.useRef)(null);
	const stickOrigin = (0, import_react.useRef)({
		x: 0,
		y: 0
	});
	const [phase, setPhase] = (0, import_react.useState)("load");
	const [progress, setProgress] = (0, import_react.useState)({
		t: .05,
		label: "Otwieram mapę Chełmka…"
	});
	const [avatar, setAvatar] = (0, import_react.useState)("maja");
	const [street, setStreet] = (0, import_react.useState)("Plac Jana Kilińskiego");
	const [near, setNear] = (0, import_react.useState)(null);
	const [landmarks, setLandmarks] = (0, import_react.useState)([]);
	const [found, setFound] = (0, import_react.useState)(/* @__PURE__ */ new Set());
	const [journal, setJournal] = (0, import_react.useState)(false);
	const [sound, setSound] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const [heading, setHeading] = (0, import_react.useState)("N");
	const [knob, setKnob] = (0, import_react.useState)({
		x: 0,
		y: 0
	});
	const [running, setRunning] = (0, import_react.useState)(false);
	const [gfx, setGfx] = (0, import_react.useState)("Obraz");
	const bus = (0, import_react.useRef)({
		onProgress: (t, label) => setProgress({
			t,
			label
		}),
		onReady: (list) => {
			setLandmarks(list);
			setPhase("pick");
		},
		onStreet: (name) => setStreet(name),
		onDiscover: (id) => {
			setFound((prev) => {
				if (prev.has(id)) return prev;
				const next = new Set(prev);
				next.add(id);
				return next;
			});
		},
		onNear: (place) => setNear(place),
		onFail: (message) => setError(message)
	});
	(0, import_react.useEffect)(() => {
		const view = viewRef.current;
		const mini = miniRef.current;
		if (!view || !mini) return;
		let dead = false;
		let handle = null;
		(async () => {
			try {
				const { mountGame } = await import("./engine-Hg3T07Yd.mjs");
				if (dead) return;
				handle = await mountGame({
					view,
					mini,
					bus
				});
				if (dead) {
					handle.dispose();
					return;
				}
				handleRef.current = handle;
				try {
					const raw = localStorage.getItem(SAVE_KEY);
					if (!raw) return;
					const saved = JSON.parse(raw);
					if (saved.avatar === "maja" || saved.avatar === "olek" || saved.avatar === "rysiek") {
						setAvatar(saved.avatar);
						handle.setAvatar(saved.avatar);
					}
					if (saved.found?.length) setFound(new Set(saved.found));
				} catch {}
			} catch (err) {
				if (!dead) setError(err instanceof Error ? err.message : "Nie udało się złożyć miasta.");
			}
		})();
		return () => {
			dead = true;
			handle?.dispose();
			handleRef.current = null;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (phase === "load") return;
		localStorage.setItem(SAVE_KEY, JSON.stringify({
			v: 1,
			avatar,
			found: [...found]
		}));
	}, [
		avatar,
		found,
		phase
	]);
	(0, import_react.useEffect)(() => {
		if (phase !== "walk") return;
		const id = window.setInterval(() => {
			setHeading(compassLabel(handleRef.current?.getYaw() ?? 0));
		}, 180);
		return () => window.clearInterval(id);
	}, [phase]);
	function choose(id) {
		setAvatar(id);
		handleRef.current?.setAvatar(id);
	}
	function enterTown() {
		handleRef.current?.setAvatar(avatar);
		handleRef.current?.startWalk();
		setPhase("walk");
		setJournal(false);
		setNear(null);
	}
	function backToPeople() {
		handleRef.current?.backToSelect();
		setPhase("pick");
		setRunning(false);
		setKnob({
			x: 0,
			y: 0
		});
		handleRef.current?.setTouch(0, 0);
		handleRef.current?.setRun(false);
	}
	const foundCount = landmarks.filter((mark) => found.has(mark.id)).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative h-full w-full overflow-hidden bg-ink text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: viewRef,
				className: "absolute inset-0 h-full w-full touch-none"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: miniRef,
				"aria-hidden": "true",
				className: "pointer-events-none absolute top-3 right-3 z-10 h-36 w-36 rounded-2xl border border-line " + (phase === "walk" ? "opacity-100" : "invisible")
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 z-20 flex items-center justify-center p-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "max-w-md rounded-2xl bg-paper p-6 text-ink",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-3xl",
						children: "Coś poszło nie tak"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: error
					})]
				})
			}) : null,
			phase === "load" && !error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 z-20 flex items-center justify-center p-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "w-full max-w-md rounded-2xl bg-paper px-6 py-7 text-ink",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold tracking-widest text-brick uppercase",
							children: "Małopolskie · 32-660"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-2 font-display text-5xl leading-none",
							children: "Chełmek"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-sm leading-relaxed text-muted",
							children: progress.label
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-5 h-1.5 overflow-hidden rounded-full bg-line",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-full bg-brick transition-all",
								style: { width: `${Math.round(progress.t * 100)}%` }
							})
						})
					]
				})
			}) : null,
			phase === "pick" && !error ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "absolute inset-x-3 bottom-3 z-20 max-h-[68%] overflow-auto rounded-2xl bg-paper p-5 text-ink md:inset-y-6 md:right-auto md:left-6 md:w-96 md:max-h-none",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold tracking-widest text-brick uppercase",
						children: "Województwo małopolskie · 32-660"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 font-display text-5xl leading-none",
						children: "Chełmek"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-relaxed text-muted",
						children: "Wybierz postać i wejdź na Plac Jana Kilińskiego. Układ ulic, obrysy budynków i Przemsza są w skali miasta — złożone z planu OpenStreetMap, nie ze skanu Google Earth."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 grid gap-2",
						children: AVATAR_META.map((person) => {
							const on = avatar === person.id;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => choose(person.id),
								className: "flex items-center gap-3 rounded-2xl border px-3 py-3 text-left " + (on ? "border-brick bg-paper-2" : "border-line bg-paper"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `h-12 w-3 shrink-0 rounded-full ${ACCENT[person.id]}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block font-display text-2xl leading-none",
									children: person.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "mt-1 block text-sm text-muted",
									children: [
										person.line,
										". ",
										person.blurb
									]
								})] })]
							}, person.id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: enterTown,
						className: "mt-4 flex h-12 w-full items-center justify-center gap-2 rounded-2xl bg-brick px-4 font-semibold text-paper",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footprints, { className: "size-5" }), "Wejdź na plac"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs leading-relaxed text-muted",
						children: "W i S idą naprzód i wstecz, A skręca w lewo, D w prawo. Shift to bieg. Na telefonie jest drążek. Obraz jest odroczony: G-buffer, trzy kaskady cieni, głębia ostrości i mgła liczona ray marchingiem."
					})
				]
			}) : null,
			phase === "walk" && !error ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "pointer-events-none absolute top-3 left-3 z-10 mr-40 max-w-56 rounded-2xl bg-paper/95 px-4 py-3 text-ink sm:max-w-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold tracking-widest text-brick uppercase",
							children: "Chełmek · 32-660"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-2xl leading-tight",
							children: street
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 flex items-center gap-3 text-xs text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Compass, { className: "size-3.5" }), heading]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3.5" }),
									foundCount,
									"/",
									landmarks.length || 0
								]
							})]
						})
					]
				}),
				near ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pointer-events-none absolute top-28 right-3 left-3 z-10 mx-auto w-full max-w-sm rounded-2xl bg-ink/90 px-4 py-3 text-paper md:top-auto md:bottom-6 md:left-6 md:mx-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold tracking-widest text-gold uppercase",
						children: kindLabel(near.kind, near.name)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-display text-xl leading-tight",
						children: near.name
					})]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute right-3 bottom-3 z-10 flex flex-col items-end gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setGfx(handleRef.current?.cycleGfx() ?? "Obraz"),
							className: "flex h-11 items-center gap-2 rounded-full bg-paper px-4 text-sm font-semibold text-ink",
							children: gfx
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setSound(handleRef.current?.toggleSound() ?? false),
							className: "flex h-11 w-11 items-center justify-center rounded-full bg-paper text-ink",
							"aria-label": sound ? "Wyłącz dźwięk" : "Włącz szum miasta",
							children: sound ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setJournal((v) => !v),
							className: "flex h-11 items-center gap-2 rounded-full bg-paper px-4 text-sm font-semibold text-ink",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "size-4" }), "Miejsca"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => handleRef.current?.returnToSquare(),
							className: "flex h-11 items-center gap-2 rounded-full bg-paper px-4 text-sm font-semibold text-ink",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "Na plac"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: backToPeople,
							className: "flex h-11 items-center gap-2 rounded-full bg-pine px-4 text-sm font-semibold text-paper",
							children: "Zmień postać"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pointer-events-none absolute bottom-4 left-1/2 z-10 hidden -translate-x-1/2 rounded-full bg-paper/90 px-4 py-2 text-xs text-muted md:block",
					children: "W naprzód · S wstecz · A lewo · D prawo · Shift bieg"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute bottom-28 left-4 z-10 h-28 w-28 touch-none rounded-full border border-line bg-paper/80 md:hidden",
					onPointerDown: (event) => {
						event.currentTarget.setPointerCapture(event.pointerId);
						const rect = event.currentTarget.getBoundingClientRect();
						stickOrigin.current = {
							x: rect.left + rect.width / 2,
							y: rect.top + rect.height / 2
						};
					},
					onPointerMove: (event) => {
						if (!event.currentTarget.hasPointerCapture(event.pointerId)) return;
						const dx = event.clientX - stickOrigin.current.x;
						const dy = event.clientY - stickOrigin.current.y;
						const max = 40;
						const scale = Math.min(1, max / (Math.hypot(dx, dy) || 1));
						const x = dx * scale;
						const y = dy * scale;
						setKnob({
							x,
							y
						});
						handleRef.current?.setTouch(Math.max(-1, Math.min(1, -x / max)), Math.max(-1, Math.min(1, -y / max)));
					},
					onPointerUp: (event) => {
						if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId);
						setKnob({
							x: 0,
							y: 0
						});
						handleRef.current?.setTouch(0, 0);
					},
					onPointerCancel: () => {
						setKnob({
							x: 0,
							y: 0
						});
						handleRef.current?.setTouch(0, 0);
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "absolute top-1/2 left-1/2 h-12 w-12 rounded-full bg-brick",
						style: { transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))` }
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "absolute right-4 bottom-48 z-10 h-14 rounded-full px-5 text-sm font-semibold md:hidden " + (running ? "bg-brick text-paper" : "bg-paper text-ink"),
					onPointerDown: () => {
						setRunning(true);
						handleRef.current?.setRun(true);
					},
					onPointerUp: () => {
						setRunning(false);
						handleRef.current?.setRun(false);
					},
					onPointerLeave: () => {
						setRunning(false);
						handleRef.current?.setRun(false);
					},
					children: "Bieg"
				}),
				journal ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "absolute inset-x-3 top-24 bottom-24 z-20 overflow-auto rounded-2xl bg-paper p-4 text-ink sm:inset-x-auto sm:right-3 sm:w-80",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-2xl",
							children: "Miejsca"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "text-sm font-semibold text-brick",
							onClick: () => setJournal(false),
							children: "Zamknij"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 grid gap-2",
						children: landmarks.map((mark) => {
							const seen = found.has(mark.id);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "rounded-xl border px-3 py-2 " + (seen ? "border-line bg-paper-2" : "border-line opacity-70"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs font-semibold tracking-wide text-brick uppercase",
									children: [kindLabel(mark.kind, mark.name), seen ? " · odwiedzone" : ""]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm leading-snug",
									children: mark.name
								})]
							}, mark.id);
						})
					})]
				}) : null
			] }) : null
		]
	});
}
var routes_exports = /* @__PURE__ */ __exportAll({ component: () => Home });
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChelmekGame, {});
}
//#endregion
export { createAvatar as n, poseAvatar as r, routes_exports as t };

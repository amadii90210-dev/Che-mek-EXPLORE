//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D9JPGnus.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-L-8HZsiS.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-L-8HZsiS.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-u9xWxms-.js"]
	}
} });
//#endregion
export { tsrStartManifest };
